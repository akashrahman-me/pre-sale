module.exports = {
  "*.{css,js,ts,tsx,json,md}": "prettier -w",
};
