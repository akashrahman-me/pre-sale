export default function Terms() {
  return <>Terms</>;
}
