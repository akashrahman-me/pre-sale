import React from "react";

function Button() {
  return <div>Button</div>;
}

export default Button;
